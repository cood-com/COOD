// Firebase Auth Logic (Shared for Login & Signup)

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyBuj4M1NihVX2VLBMW7DJLqtUFA0Ry4Lig",
  authDomain: "cood-db596.firebaseapp.com",
  projectId: "cood-db596",
  storageBucket: "cood-db596.appspot.com",
  messagingSenderId: "709801459625",
  appId: "1:709801459625:web:4a4ce957dea49570ecceb8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Handle Sign Up
const signupForm = document.getElementById("signup-form");
if (signupForm) {
  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;

    createUserWithEmailAndPassword(auth, email, password)
      .then(() => {
        alert("Account created!");
        window.location.href = "login.html";
      })
      .catch((error) => alert(error.message));
  });
}

// Handle Login
const loginForm = document.getElementById("login-form");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    signInWithEmailAndPassword(auth, email, password)
      .then(() => {
        alert("Login successful!");
        window.location.href = "../profile.html"; // After login
      })
      .catch((error) => alert(error.message));
  });
}