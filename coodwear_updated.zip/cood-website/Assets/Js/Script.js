// ------------------- FIREBASE SETUP -------------------
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import { getFirestore, collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBuj4M1NihVX2VLBMW7DJLqtUFA0Ry4Lig",
  authDomain: "cood-db596.firebaseapp.com",
  projectId: "cood-db596",
  storageBucket: "cood-db596.appspot.com",
  messagingSenderId: "709801459625",
  appId: "1:709801459625:web:4a4ce957dea49570ecceb8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ------------------- LOCAL STORAGE CART -------------------
let cart = JSON.parse(localStorage.getItem("coodCart")) || [];

// Add to cart
function addToCart(id, name, price, image) {
  const existing = cart.find(item => item.id === id);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({ id, name, price, image, quantity: 1 });
  }

  localStorage.setItem("coodCart", JSON.stringify(cart));
  alert(`${name} added to cart!`);
  displayCart();
}

// Display cart with total
function displayCart() {
  const cartContainer = document.getElementById("cart-items");
  const totalPriceEl = document.getElementById("total-price");
  const totalQuantityEl = document.getElementById("total-quantity");

  if (!cartContainer || !totalPriceEl) return;

  cartContainer.innerHTML = "";
  let total = 0;
  let quantity = 0;

  cart.forEach(item => {
    const itemEl = document.createElement("div");
    itemEl.className = "cart-item";
    itemEl.innerHTML = `
      <img src="${item.image}" width="60">
      <div>
        <h4>${item.name}</h4>
        <p>₹${item.price} × ${item.quantity}</p>
        <button onclick="removeFromCart('${item.id}')">Remove</button>
      </div>
    `;
    cartContainer.appendChild(itemEl);
    total += item.price * item.quantity;
    quantity += item.quantity;
  });

  totalPriceEl.innerText = `Total Price: ₹${total}`;
  if (totalQuantityEl) {
    totalQuantityEl.innerText = `Total Items: ${quantity}`;
  }
}

// Remove item
function removeFromCart(id) {
  cart = cart.filter(item => item.id !== id);
  localStorage.setItem("coodCart", JSON.stringify(cart));
  displayCart();
}

// Checkout with Firebase
function checkoutCart() {
  if (cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const quantity = cart.reduce((sum, item) => sum + item.quantity, 0);

  onAuthStateChanged(auth, async (user) => {
    if (user) {
      try {
        await addDoc(collection(db, "orders"), {
          uid: user.uid,
          email: user.email,
          items: cart,
          total,
          quantity,
          createdAt: serverTimestamp()
        });
        alert("Order placed successfully!");
      } catch (err) {
        console.error("Firestore error:", err);
        alert("Error saving order.");
      }
    } else {
      alert("Not logged in. Order will not be saved.");
    }

    cart = [];
    localStorage.removeItem("coodCart");
    displayCart();
  });
}

// ------------------- PAGINATION -------------------
document.addEventListener('DOMContentLoaded', () => {
  const cards = Array.from(document.querySelectorAll('#product-list .card'));
  const pagination = document.getElementById('pagination');
  const perPage = 4;
  let currentPage = 1;

  function showPage(page) {
    const start = (page - 1) * perPage;
    const end = start + perPage;
    cards.forEach((card, index) => {
      card.style.display = index >= start && index < end ? 'block' : 'none';
    });
    renderPagination();
  }

  function renderPagination() {
    const totalPages = Math.ceil(cards.length / perPage);
    pagination.innerHTML = '';
    for (let i = 1; i <= totalPages; i++) {
      const btn = document.createElement('button');
      btn.innerText = i;
      btn.classList.add('btn');
      if (i === currentPage) btn.style.backgroundColor = '#111';
      btn.addEventListener('click', () => {
        currentPage = i;
        showPage(i);
      });
      pagination.appendChild(btn);
    }
  }

  if (cards.length > 0) showPage(currentPage);
});

// ------------------- WISHLIST -------------------
document.querySelectorAll('.wishlist-btn').forEach(btn => {
  const id = btn.getAttribute('data-id');
  if (localStorage.getItem('wishlist-' + id)) {
    btn.textContent = '💔 Remove';
  }

  btn.addEventListener('click', () => {
    if (localStorage.getItem('wishlist-' + id)) {
      localStorage.removeItem('wishlist-' + id);
      btn.textContent = '❤️ Save';
    } else {
      const card = btn.closest('.card');
      const item = {
        id,
        name: card.getAttribute('data-name'),
        price: card.getAttribute('data-price'),
        size: card.getAttribute('data-size'),
        image: card.querySelector('img').src
      };
      localStorage.setItem('wishlist-' + id, JSON.stringify(item));
      btn.textContent = '💔 Remove';
    }
  });
});

// ------------------- FILTER -------------------
const searchBox = document.getElementById('search-box');
const sizeFilter = document.getElementById('size-filter');
const priceFilter = document.getElementById('price-filter');
const productCards = document.querySelectorAll('.card');

function filterProducts() {
  const search = searchBox?.value.toLowerCase() || "";
  const size = sizeFilter?.value;
  const price = priceFilter?.value;

  productCards.forEach(card => {
    const name = card.dataset.name.toLowerCase();
    const cardSize = card.dataset.size;
    const cardPrice = parseInt(card.dataset.price);

    let show = true;

    if (search && !name.includes(search)) show = false;
    if (size && size !== cardSize) show = false;

    if (price === "0-499" && cardPrice > 499) show = false;
    if (price === "500-999" && (cardPrice < 500 || cardPrice > 999)) show = false;
    if (price === "1000+" && cardPrice < 1000) show = false;

    card.style.display = show ? "block" : "none";
  });
}

searchBox?.addEventListener("input", filterProducts);
sizeFilter?.addEventListener("change", filterProducts);
priceFilter?.addEventListener("change", filterProducts);